/* Este arquivo testa as funções de ordenação do programa. */
#define main menu_do_programa
#include "../atividade_final_ordenacao_arquivos.c"
#undef main

#include <assert.h>
#include <stdio.h>

void conferirResultado(int valores[]) {
    int esperado[] = {-2, 1, 4, 5, 8};
    int i;

    for (i = 0; i < 5; i++) {
        assert(valores[i] == esperado[i]);
    }
}

int main(void) {
    int valores[5];

    valores[0] = 5; valores[1] = -2; valores[2] = 8;
    valores[3] = 1; valores[4] = 4;
    bubbleSort(valores, 5);
    conferirResultado(valores);
    printf("Bubble Sort: OK\n");

    valores[0] = 5; valores[1] = -2; valores[2] = 8;
    valores[3] = 1; valores[4] = 4;
    insertionSort(valores, 5);
    conferirResultado(valores);
    printf("Insertion Sort: OK\n");

    valores[0] = 5; valores[1] = -2; valores[2] = 8;
    valores[3] = 1; valores[4] = 4;
    selectionSort(valores, 5);
    conferirResultado(valores);
    printf("Selection Sort: OK\n");

    valores[0] = 5; valores[1] = -2; valores[2] = 8;
    valores[3] = 1; valores[4] = 4;
    mergeSort(valores, 0, 4);
    conferirResultado(valores);
    printf("Merge Sort: OK\n");

    valores[0] = 5; valores[1] = -2; valores[2] = 8;
    valores[3] = 1; valores[4] = 4;
    quickSort(valores, 0, 4);
    conferirResultado(valores);
    printf("Quick Sort: OK\n");

    printf("Todos os testes passaram.\n");
    return 0;
}
