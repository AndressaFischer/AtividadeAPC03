#include <stdio.h>
#include <stdlib.h>

#define MAX 100

/* Grava os números digitados em dados.txt. */
void criarArquivo(void) {
    FILE *arquivo;
    int quantidade, numero, i;

    printf("Quantos numeros deseja gravar? (maximo %d): ", MAX);
    scanf("%d", &quantidade);

    if (quantidade < 1 || quantidade > MAX) {
        printf("Digite uma quantidade entre 1 e %d.\n", MAX);
        return;
    }

    arquivo = fopen("dados.txt", "w");
    if (arquivo == NULL) {
        printf("Erro ao abrir dados.txt.\n");
        return;
    }

    for (i = 0; i < quantidade; i++) {
        printf("Digite o numero %d: ", i + 1);
        scanf("%d", &numero);
        fprintf(arquivo, "%d\n", numero);
    }

    fclose(arquivo);
    printf("Dados gravados em dados.txt.\n");
}

/* Lê os números de um arquivo e coloca-os no vetor. */
int lerArquivo(const char *nome, int valores[]) {
    FILE *arquivo = fopen(nome, "r");
    int quantidade = 0;

    if (arquivo == NULL) {
        return -1;
    }

    while (quantidade < MAX && fscanf(arquivo, "%d", &valores[quantidade]) == 1) {
        quantidade++;
    }

    fclose(arquivo);
    return quantidade;
}

/* Mostra os números de um arquivo. */
void mostrarArquivo(const char *nome) {
    int valores[MAX];
    int quantidade = lerArquivo(nome, valores);
    int i;

    if (quantidade == -1) {
        printf("Nao foi possivel abrir %s.\n", nome);
        return;
    }

    if (quantidade == 0) {
        printf("O arquivo esta vazio.\n");
        return;
    }

    for (i = 0; i < quantidade; i++) {
        printf("%d: %d\n", i + 1, valores[i]);
    }
}

/* Bubble Sort. */
void bubbleSort(int valores[], int quantidade) {
    int i, j, auxiliar;

    for (i = 0; i < quantidade - 1; i++) {
        for (j = 0; j < quantidade - i - 1; j++) {
            if (valores[j] > valores[j + 1]) {
                auxiliar = valores[j];
                valores[j] = valores[j + 1];
                valores[j + 1] = auxiliar;
            }
        }
    }
}

/* Insertion Sort. */
void insertionSort(int valores[], int quantidade) {
    int i, j, chave;

    for (i = 1; i < quantidade; i++) {
        chave = valores[i];
        j = i - 1;

        while (j >= 0 && valores[j] > chave) {
            valores[j + 1] = valores[j];
            j--;
        }

        valores[j + 1] = chave;
    }
}

/* Selection Sort. */
void selectionSort(int valores[], int quantidade) {
    int i, j, menor, auxiliar;

    for (i = 0; i < quantidade - 1; i++) {
        menor = i;

        for (j = i + 1; j < quantidade; j++) {
            if (valores[j] < valores[menor]) {
                menor = j;
            }
        }

        auxiliar = valores[i];
        valores[i] = valores[menor];
        valores[menor] = auxiliar;
    }
}

/* Junta duas partes ordenadas do vetor. */
void intercalar(int valores[], int inicio, int meio, int fim) {
    int auxiliar[MAX];
    int i = inicio;
    int j = meio + 1;
    int k = 0;

    while (i <= meio && j <= fim) {
        if (valores[i] <= valores[j]) {
            auxiliar[k] = valores[i];
            i++;
        } else {
            auxiliar[k] = valores[j];
            j++;
        }
        k++;
    }

    while (i <= meio) {
        auxiliar[k] = valores[i];
        i++;
        k++;
    }

    while (j <= fim) {
        auxiliar[k] = valores[j];
        j++;
        k++;
    }

    for (i = inicio, k = 0; i <= fim; i++, k++) {
        valores[i] = auxiliar[k];
    }
}

/* Merge Sort. */
void mergeSort(int valores[], int inicio, int fim) {
    int meio;

    if (inicio < fim) {
        meio = (inicio + fim) / 2;
        mergeSort(valores, inicio, meio);
        mergeSort(valores, meio + 1, fim);
        intercalar(valores, inicio, meio, fim);
    }
}

/* Quick Sort. */
void quickSort(int valores[], int inicio, int fim) {
    int i = inicio;
    int j = fim;
    int pivo = valores[(inicio + fim) / 2];
    int auxiliar;

    while (i <= j) {
        while (valores[i] < pivo) {
            i++;
        }
        while (valores[j] > pivo) {
            j--;
        }

        if (i <= j) {
            auxiliar = valores[i];
            valores[i] = valores[j];
            valores[j] = auxiliar;
            i++;
            j--;
        }
    }

    if (inicio < j) {
        quickSort(valores, inicio, j);
    }
    if (i < fim) {
        quickSort(valores, i, fim);
    }
}

/* Salva os números ordenados em ordenado.txt. */
void salvarOrdenado(int valores[], int quantidade) {
    FILE *arquivo = fopen("ordenado.txt", "w");
    int i;

    if (arquivo == NULL) {
        printf("Erro ao gravar ordenado.txt.\n");
        return;
    }

    for (i = 0; i < quantidade; i++) {
        fprintf(arquivo, "%d\n", valores[i]);
    }

    fclose(arquivo);
    printf("Valores ordenados e salvos em ordenado.txt.\n");
}

/* Lê os dados, chama o algoritmo escolhido e grava o resultado. */
void ordenarArquivo(void) {
    int valores[MAX];
    int quantidade = lerArquivo("dados.txt", valores);
    int opcao;

    if (quantidade == -1) {
        printf("Nao foi possivel abrir dados.txt. Crie o arquivo primeiro.\n");
        return;
    }

    if (quantidade == 0) {
        printf("Nao ha numeros para ordenar.\n");
        return;
    }

    printf("\nEscolha o algoritmo:\n");
    printf("1 - Bubble Sort\n");
    printf("2 - Insertion Sort\n");
    printf("3 - Selection Sort\n");
    printf("4 - Merge Sort\n");
    printf("5 - Quick Sort\n");
    printf("Opcao: ");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1:
            bubbleSort(valores, quantidade);
            break;
        case 2:
            insertionSort(valores, quantidade);
            break;
        case 3:
            selectionSort(valores, quantidade);
            break;
        case 4:
            mergeSort(valores, 0, quantidade - 1);
            break;
        case 5:
            quickSort(valores, 0, quantidade - 1);
            break;
        default:
            printf("Opcao invalida.\n");
            return;
    }

    salvarOrdenado(valores, quantidade);
}

/* Altera uma posição usando um arquivo temporário. */
int alterarValor(int posicao, int novoValor) {
    FILE *arquivo = fopen("dados.txt", "r");
    FILE *temporario;
    int valor, atual = 1, encontrou = 0;

    if (arquivo == NULL) {
        printf("Nao foi possivel abrir dados.txt. Crie o arquivo primeiro.\n");
        return 0;
    }

    temporario = fopen("temporario.txt", "w");
    if (temporario == NULL) {
        fclose(arquivo);
        printf("Erro ao criar arquivo temporario.\n");
        return 0;
    }

    while (fscanf(arquivo, "%d", &valor) == 1) {
        if (atual == posicao) {
            fprintf(temporario, "%d\n", novoValor);
            encontrou = 1;
        } else {
            fprintf(temporario, "%d\n", valor);
        }
        atual++;
    }

    fclose(arquivo);
    fclose(temporario);

    if (encontrou == 0) {
        remove("temporario.txt");
        printf("Essa posicao nao existe.\n");
        return 0;
    }

    remove("dados.txt");
    if (rename("temporario.txt", "dados.txt") != 0) {
        printf("Erro ao atualizar dados.txt.\n");
        return 0;
    }

    printf("Valor alterado em dados.txt.\n");
    return 1;
}

/* Altera um número e chama a ordenação novamente. */
void alterarEOrdenar(void) {
    int posicao, novoValor;

    printf("\nValores de dados.txt (posicao: valor):\n");
    mostrarArquivo("dados.txt");

    printf("Digite a posicao que deseja alterar: ");
    scanf("%d", &posicao);
    printf("Digite o novo valor: ");
    scanf("%d", &novoValor);

    if (alterarValor(posicao, novoValor)) {
        printf("Agora escolha um metodo para ordenar novamente.\n");
        ordenarArquivo();
    }
}

int main(void) {
    int opcao;

    do {
        printf("\n===== MENU =====\n");
        printf("1 - Criar dados.txt\n");
        printf("2 - Mostrar dados.txt\n");
        printf("3 - Ordenar e salvar em ordenado.txt\n");
        printf("4 - Alterar um valor e ordenar novamente\n");
        printf("5 - Mostrar ordenado.txt\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                criarArquivo();
                break;
            case 2:
                mostrarArquivo("dados.txt");
                break;
            case 3:
                ordenarArquivo();
                break;
            case 4:
                alterarEOrdenar();
                break;
            case 5:
                mostrarArquivo("ordenado.txt");
                break;
            case 0:
                printf("Programa encerrado.\n");
                break;
            default:
                printf("Opcao invalida.\n");
        }
    } while (opcao != 0);

    return 0;
}
